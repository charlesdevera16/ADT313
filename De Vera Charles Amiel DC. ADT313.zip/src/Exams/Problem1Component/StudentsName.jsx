import React from 'react';

const Student = ({ name }) => {
  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px' }}>
      <h3>Student Name</h3>
      <p>{name}</p>
    </div>
  );
};

export default Student;