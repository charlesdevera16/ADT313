import React from 'react';

const Section = ({ section }) => {
  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px' }}>
      <h3>Student Section</h3>
      <p>{section}</p>
    </div>
  );
};

export default Section;