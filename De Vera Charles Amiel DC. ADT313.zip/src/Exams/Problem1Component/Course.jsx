import React from 'react';

const Course = ({ course }) => {
  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px' }}>
      <h3>Student Course</h3>
      <p>{course}</p>
    </div>
  );
};

export default Course;