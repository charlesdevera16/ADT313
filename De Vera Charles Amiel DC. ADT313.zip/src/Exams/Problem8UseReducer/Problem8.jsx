import React, { useReducer } from 'react';
import data from './problem8mock_data.json';

// Initial state
const initialState = {
  foods: data,
  selectedFood: null,
};

// Reducer function
const reducer = (state, action) => {
  switch (action.type) {
    case 'CREATE':
      return { ...state, foods: [...state.foods, action.payload] };
    case 'READ':
      return { ...state, selectedFood: action.payload };
    case 'UPDATE':
      return {
        ...state,
        foods: state.foods.map(food =>
          food.food_name === action.payload.food_name ? action.payload : food
        ),
        selectedFood: null,
      };
    case 'DELETE':
      return {
        ...state,
        foods: state.foods.filter(food => food.food_name !== action.payload),
        selectedFood: null,
      };
    case 'CLEAR':
      return { ...state, selectedFood: null };
    default:
      throw new Error('Unknown action type');
  }
};

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { foods, selectedFood } = state;

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    dispatch({
      type: 'READ',
      payload: { ...selectedFood, [name]: value },
    });
  };

  // Handle save or update
  const handleSave = () => {
    if (selectedFood) {
      dispatch({ type: 'UPDATE', payload: selectedFood });
    } else {
      const newFood = {
        food_name: document.querySelector('input[name="food_name"]').value,
        price: document.querySelector('input[name="price"]').value,
        expiration_date: document.querySelector('input[name="expiration_date"]').value,
        calories: document.querySelector('input[name="calories"]').value,
      };
      dispatch({ type: 'CREATE', payload: newFood });
    }
  };

  // Handle edit button click
  const handleEdit = (food) => {
    dispatch({ type: 'READ', payload: food });
  };

  // Handle delete button click
  const handleDelete = (food_name) => {
    dispatch({ type: 'DELETE', payload: food_name });
  };

  // Handle clear button click
  const handleClear = () => {
    dispatch({ type: 'CLEAR' });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={selectedFood ? selectedFood.food_name : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={selectedFood ? selectedFood.price : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={selectedFood ? selectedFood.expiration_date : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={selectedFood ? selectedFood.calories : ''}
            onChange={handleInputChange}
          />
        </div>

        <button type='button' onClick={handleSave}>
          {selectedFood ? 'Update' : 'Save'}
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.food_name}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(food.food_name)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}